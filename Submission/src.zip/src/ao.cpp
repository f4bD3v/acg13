/*
	This file is part of Nori, a simple educational ray tracer

	Copyright (c) 2012 by Wenzel Jakob and Steve Marschner.

	Nori is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License Version 3
	as published by the Free Software Foundation.

	Nori is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include <nori/integrator.h>
#include <nori/sampler.h>
#include <nori/scene.h>

NORI_NAMESPACE_BEGIN

Vector3f hemisphereSampling(const Point2f &sample) {
		float cosTheta = sample.x();
		float sinTheta = std::sqrt(std::max((float) 0, 1-cosTheta*cosTheta));

		float sinPhi, cosPhi;
		sincosf(2.0f * M_PI * sample.y(), &sinPhi, &cosPhi);

		return Vector3f(cosPhi * sinTheta, sinPhi * sinTheta, cosTheta);
}

/**
 * \brief Ambient occlusion: a very simple rendering technique that
 * approximates ambient lighting by accounting for local shadowing.
 */
class AmbientOcclusion : public Integrator {
public:
	AmbientOcclusion(const PropertyList &propList) {
		/* Ray length of the ambient occlusion queries;
		   expressed relative to the scene size */
		m_length = propList.getFloat("length", 0.1f);
	}

	Color3f Li(const Scene *scene, Sampler *sampler, const Ray3f &ray, ImageBlock *) const {
		/* Find the surface that is visible in the requested direction */
		Intersection its;
		if (!scene->rayIntersect(ray, its))
			return Color3f(0.0f);

		/* Sample (naively) from the hemisphere (local coordinates) */
		Vector3f d = hemisphereSampling(sampler->next2D());

		/* Use the shading frame at "its" to convert it to world coordinates */
		d = its.toWorld(d);

		/* Determine the length of the "shadow ray" based on the scene size
		   and the configuration options */
		float length = m_length * scene->getBoundingBox().getExtents().norm();

		/* Create a new outgoing ray having extents (epsilon, length) */
		Ray3f shadowRay(its.p, d, Epsilon, length);

		/* Perform an occlusion test and return one or zero depending on the result */
		return Color3f(scene->rayIntersect(shadowRay) ? 0.0f : 1.0f);
	}

	QString toString() const {
		return QString("AmbientOcclusion[length=%1]").arg(m_length);
	}
private:
	float m_length;
};

NORI_REGISTER_CLASS(AmbientOcclusion, "ao");
NORI_NAMESPACE_END
